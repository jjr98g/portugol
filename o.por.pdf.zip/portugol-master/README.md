# portugol
aprendendo uso de bibliotecas e funções
